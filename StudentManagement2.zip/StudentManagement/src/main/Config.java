package main;

import beans.Student;

public class Config {
    public static Student[]studentns=null;


}
